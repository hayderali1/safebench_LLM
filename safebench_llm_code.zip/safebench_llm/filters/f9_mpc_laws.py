"""
F9 -- MPC with CBF constraints  (Aksun-Guvenc et al., Electronics 14(3) 2025;
                                 Zeng et al., MPC-CBF, IEEE T-CST 2021).

Mathematical statement:
    min_{u_0,...,u_{N-1}}   sum_k ||x_k - x_ref||_Q^2 + ||u_k||_R^2
    s.t.   x_{k+1} = F(x_k, u_k)             (discrete dynamics)
           h(x_{k+1}) >= (1 - gamma) h(x_k)  (DCBF constraint per stage)
           u_min <= u_k <= u_max
We linearise F around a forward roll-out of  u_nom  to keep the QP convex.

LAWS -- Latency-Adaptive Wrapper for Safety-filters.
This is the *composable decorator* described in the paper.  It wraps any
SafetyFilter and inflates each barrier by

      L_h ( v_max * tau_hat  +  e_x )

where  L_h        : Lipschitz bound on h    (Cosner et al. 2021)
       v_max      : speed bound
       tau_hat    : online estimate of supervisor latency
                    (gradient-descent estimator from Kim et al. 2025)
       e_x        : measurement-error bound  (MR-CBF, Cosner et al. 2021)

The decorator tightens the barrier seen by the wrapped filter so that
the filter behaves as if it were operating  tau_hat  seconds in the past
on a state estimate degraded by  e_x.  See Algorithm 1 of the paper.
"""
from __future__ import annotations
import time
from collections import deque
from typing import List, Tuple
import numpy as np
import cvxpy as cp

from .base import SafetyFilter, FilterDiagnostics, Obstacle
from ..utils.dynamics import (A_MIN, A_MAX, DELTA_MAX, V_MAX,
                              step_rk4)


class MPC_CBF(SafetyFilter):
    """F9 - MPC with discrete-CBF terminal/stage constraints."""
    name = "F9_MPC_CBF"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0,
                 N: int = 5, gamma: float = 0.3,
                 Q: np.ndarray = None, R: np.ndarray = None):
        super().__init__(alpha=alpha, safe_dist=safe_dist)
        self.N     = N
        self.gamma = gamma
        self.Q     = np.diag([0.0, 0.5, 1.0, 0.1]) if Q is None else Q
        self.R     = np.diag([0.1, 0.5])           if R is None else R

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        N = self.N

        # Reference: hold current speed and heading, roll forward
        x_ref_traj = [state.copy()]
        for _ in range(N):
            x_ref_traj.append(step_rk4(x_ref_traj[-1], np.asarray(u_nom), dt))

        # Linearise dynamics around the reference roll-out
        eps = 1e-3
        A_list, B_list = [], []
        for k in range(N):
            xk = x_ref_traj[k]; uk = np.asarray(u_nom)
            f0 = step_rk4(xk, uk, dt)
            A_k = np.zeros((4, 4))
            for i in range(4):
                dx = np.zeros(4); dx[i] = eps
                A_k[:, i] = (step_rk4(xk + dx, uk, dt) - f0) / eps
            B_k = np.zeros((4, 2))
            for j in range(2):
                du = np.zeros(2); du[j] = eps
                B_k[:, j] = (step_rk4(xk, uk + du, dt) - f0) / eps
            A_list.append(A_k); B_list.append(B_k)

        # Decision variables
        x = cp.Variable((4, N + 1))
        u = cp.Variable((2, N))
        cost = 0
        constraints = [x[:, 0] == state]
        x_ref_arr = np.stack(x_ref_traj, axis=1)
        for k in range(N):
            cost += cp.quad_form(x[:, k] - x_ref_arr[:, k], self.Q)
            cost += cp.quad_form(u[:, k] - np.asarray(u_nom), self.R)
            # linearised dynamics
            constraints += [
                x[:, k+1] == A_list[k] @ x[:, k] + B_list[k] @ u[:, k]
                            + (step_rk4(x_ref_traj[k], np.asarray(u_nom), dt)
                               - A_list[k] @ x_ref_traj[k]
                               - B_list[k] @ np.asarray(u_nom)),
                u[0, k] >= A_MIN, u[0, k] <= A_MAX,
                u[1, k] >= -DELTA_MAX, u[1, k] <= DELTA_MAX,
            ]

        # DCBF stage constraints, linearised
        h_min = np.inf
        for obs in obstacles:
            h_now = self.h_distance(state, obs, self.safe_dist)
            h_min = min(h_min, h_now)
            for k in range(N):
                ref_k1 = x_ref_traj[k+1]
                gh = np.array([2*(ref_k1[0]-obs.x), 2*(ref_k1[1]-obs.y), 0.0, 0.0])
                h_ref = self.h_distance(ref_k1, obs, self.safe_dist)
                h_lin_next = h_ref + gh @ (x[:, k+1] - ref_k1)
                # h(x_{k+1}) >= (1 - gamma) h(x_k):  use a simple linearisation
                gh_now = np.array([2*(x_ref_traj[k][0]-obs.x), 2*(x_ref_traj[k][1]-obs.y), 0.0, 0.0])
                h_lin_now = self.h_distance(x_ref_traj[k], obs, self.safe_dist) \
                            + gh_now @ (x[:, k] - x_ref_traj[k])
                constraints.append(h_lin_next >= (1.0 - self.gamma) * h_lin_now)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False
        if feas:
            u_star = np.array(u.value[:, 0])
        else:
            u_star = np.array([A_MIN, 0.0])
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag


# ---------------------------------------------------------------- LAWS
class LAWS(SafetyFilter):
    """Latency-Adaptive Wrapper for Safety-filters (Algorithm 1 of paper).

    Wraps any SafetyFilter and tightens its barrier(s) by

        L_h * ( v_max * tau_hat + e_x )

    where tau_hat is updated online from the timestamps of received
    supervisor commands using a small-gain gradient descent (Kim et al.
    2025, eq. 9).  Composes the sampled-data bound (Breeden et al. 2021)
    with the measurement-robust bound (Cosner et al. 2021).
    """
    name = "LAWS"

    def __init__(self, base_filter: SafetyFilter,
                 v_max: float = V_MAX,
                 e_x: float = 0.5,
                 L_h: float = 4.0,
                 tau_init: float = 0.1,
                 lr: float = 0.5,
                 window: int = 10):
        super().__init__(alpha=base_filter.alpha, safe_dist=base_filter.safe_dist)
        self.base   = base_filter
        self.name   = f"LAWS+{base_filter.name}"
        self.v_max  = v_max
        self.e_x    = e_x
        self.L_h    = L_h
        self.tau_hat = tau_init
        self.lr     = lr
        self.timestamps: deque = deque(maxlen=window)

    def report_supervisor_arrival(self, t_now: float):
        """Call this whenever a fresh supervisor command lands.
        The wrapper updates  tau_hat  by averaging recent inter-arrival gaps
        with a gradient step (Kim et al. 2025, eq. 9, simplified)."""
        self.timestamps.append(t_now)
        if len(self.timestamps) >= 2:
            gaps = np.diff(np.array(self.timestamps))
            measured = float(np.median(gaps))
            # gradient step:  tau_hat  <- tau_hat + lr * (measured - tau_hat)
            self.tau_hat = self.tau_hat + self.lr * (measured - self.tau_hat)

    def filter(self, state, u_nom, obstacles, dt):
        # Tighten the safety distance perceived by the inner filter:
        # equivalent to inflating each barrier by L_h (v_max tau_hat + e_x),
        # which for our distance barrier becomes a safe-distance bump.
        inflation = self.L_h * (self.v_max * self.tau_hat + self.e_x)
        # Convert constraint inflation back to an additive radius: solve
        # (r + dr)^2 - r^2 ~= inflation  =>  dr ~= inflation / (2 r)
        r = self.safe_dist
        dr = inflation / max(2.0 * r, 1e-3)
        old_safe = self.base.safe_dist
        self.base.safe_dist = old_safe + dr
        try:
            u_star, diag = self.base.filter(state, u_nom, obstacles, dt)
        finally:
            self.base.safe_dist = old_safe
        # Recompute h_min on the *uninflated* barrier so the metric is
        # comparable to non-LAWS rows in the benchmark.  (The wrapper
        # already enforces the tighter constraint internally; this is
        # just for fair reporting.)
        if obstacles:
            h_min_true = min(self.h_distance(state, o, old_safe)
                             for o in obstacles)
            diag.h_min = float(h_min_true)
        diag.notes = (diag.notes or "") + f" | LAWS tau_hat={self.tau_hat:.2f}s dr={dr:.2f}m"
        return u_star, diag
