"""
F0 -- No-safety pass-through (negative baseline).
F1 -- CBF-QP            (Ames, Xu, Grizzle, Tabuada, IEEE TAC 2017).

Mathematical statement (F1):
    u*(x) = argmin_u ||u - u_nom||^2
    s.t.  L_f h(x) + L_g h(x) u + alpha(h(x)) >= 0
For affine systems  xdot = f(x) + g(x) u.

We use the squared-distance barrier
    h(x) = ||p_ego - p_obs||^2 - r_safe^2
and the kinematic-bicycle relative degree-2 form is handled by lifting
to the velocity-projected first-order constraint
    hdot(x,u) = 2 (p_ego - p_obs)^T v_ego
(see HOCBF for the strict relative-degree-2 treatment).
"""
from __future__ import annotations
import time
import numpy as np
import cvxpy as cp
from typing import List, Tuple

from .base import SafetyFilter, FilterDiagnostics, Obstacle
from ..utils.dynamics import A_MIN, A_MAX, DELTA_MAX


# ----------------------------------------------------------------------
class NoSafetyFilter(SafetyFilter):
    """F0 - returns u_nom unchanged.  Negative baseline."""
    name = "F0_NoSafety"

    def filter(self, state, u_nom, obstacles, dt):
        diag = FilterDiagnostics(feasible=True, intervention=0.0,
                                 h_min=min((self.h_distance(state, o, self.safe_dist)
                                            for o in obstacles), default=np.inf))
        return np.asarray(u_nom, dtype=float), diag


# ----------------------------------------------------------------------
class CBF_QP(SafetyFilter):
    """F1 - first-order CBF-QP, Ames et al. 2017."""
    name = "F1_CBF_QP"

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >=  A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]

        h_min = np.inf
        a1 = a2 = self.alpha
        for obs in obstacles:
            t = self.cbf_terms(state, obs, self.safe_dist, a1, a2)
            h_min = min(h_min, t.h)
            constraints.append(t.C_const + t.C_a * u[0] + t.C_delta * u[1] >= 0)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False

        if feas:
            u_star = np.array(u.value)
        else:
            # graceful fallback: brake hard, no steering
            u_star = np.array([A_MIN, 0.0])

        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag
