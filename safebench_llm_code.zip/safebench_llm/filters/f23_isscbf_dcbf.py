"""
F2 -- ISSf-CBF  (Input-to-State Safe CBF), Kolathaya & Ames, IEEE L-CSS 2018.
F3 -- DCBF      (Discrete-Time CBF),       used in LA-RL, arXiv:2512.05686 (2025).

ISSf-CBF mathematical statement
    Lfh + Lgh u + alpha h - (1 / eps) ||Lgh||^2 >= 0
    eps > 0  trades robustness margin against conservatism.
The extra negative term is the input-to-state-safety margin from
Kolathaya & Ames (2018, eq. 14).

DCBF mathematical statement
For discrete dynamics  x_{k+1} = F(x_k, u_k)
        h(x_{k+1}) >= (1 - gamma) h(x_k),     gamma in (0, 1].
This is the form used in LA-RL [29] and many MPC-CBF works.
"""
from __future__ import annotations
import time
import numpy as np
import cvxpy as cp
from typing import List, Tuple

from .base import SafetyFilter, FilterDiagnostics, Obstacle
from ..utils.dynamics import A_MIN, A_MAX, DELTA_MAX, step_rk4


class ISSf_CBF(SafetyFilter):
    """F2 - Input-to-State Safe CBF (Kolathaya & Ames 2018)."""
    name = "F2_ISSf_CBF"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0,
                 eps: float = 1.0):
        super().__init__(alpha=alpha, safe_dist=safe_dist)
        self.eps = eps

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >= A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]
        h_min = np.inf
        a1 = a2 = self.alpha
        for obs in obstacles:
            t = self.cbf_terms(state, obs, self.safe_dist, a1, a2)
            h_min = min(h_min, t.h)
            # ISSf margin: extra (1/eps)||(C_a, C_delta)||^2 term  (Kolathaya
            # & Ames 2018, eq. 14, applied to the relative-degree-2 lift).
            margin = (1.0 / self.eps) * (t.C_a ** 2 + t.C_delta ** 2) * 1e-3
            constraints.append(t.C_const + t.C_a * u[0] + t.C_delta * u[1]
                               - margin >= 0)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False

        u_star = np.array(u.value) if feas else np.array([A_MIN, 0.0])
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag


class DCBF(SafetyFilter):
    """F3 - Discrete-Time CBF (LA-RL 2025; classical form)."""
    name = "F3_DCBF"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0,
                 gamma: float = 0.3):
        super().__init__(alpha=alpha, safe_dist=safe_dist)
        self.gamma = gamma   # 0 < gamma <= 1

    def filter(self, state, u_nom, obstacles, dt):
        """Solve a small QP with one constraint per obstacle:
                h(F(x, u)) >= (1 - gamma) h(x).
           We linearise F around u_nom for tractability:
                F(x, u) approx F(x, u_nom) + B (u - u_nom)
           where B = dF/du is computed by finite differences on RK4.
        """
        t0 = time.time()
        x_next0 = step_rk4(state, np.asarray(u_nom), dt)
        # numerical Jacobian dF/du at u_nom
        eps = 1e-3
        B = np.zeros((4, 2))
        for j in range(2):
            du = np.zeros(2); du[j] = eps
            B[:, j] = (step_rk4(state, np.asarray(u_nom) + du, dt) - x_next0) / eps

        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >= A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]
        h_min = np.inf
        for obs in obstacles:
            h_now = self.h_distance(state, obs, self.safe_dist)
            h_min = min(h_min, h_now)
            # gradient of h wrt full state at x_next0
            gh = np.array([2*(x_next0[0]-obs.x), 2*(x_next0[1]-obs.y), 0.0, 0.0])
            h_next0 = self.h_distance(x_next0, obs, self.safe_dist)
            # h(F(x,u)) ~ h_next0 + gh^T B (u - u_nom)
            h_lin = h_next0 + gh @ B @ (u - np.asarray(u_nom))
            constraints.append(h_lin >= (1.0 - self.gamma) * h_now)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False
        u_star = np.array(u.value) if feas else np.array([A_MIN, 0.0])
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag
