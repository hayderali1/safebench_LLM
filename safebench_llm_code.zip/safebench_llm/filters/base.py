"""
Common base class for every safety filter in SafeBench-LLM.

Every filter solves a problem of the form
        u* = argmin ||u - u_nom||^2
        s.t.  safety constraint(s) on u and x

and returns u*.  Subclasses override `filter()`.

References:
[1] Ames, Xu, Grizzle, Tabuada, IEEE TAC 2017 (CBF-QP).
[6] Wabersich et al., IEEE CSM 2023 (safety-filter survey).
"""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, NamedTuple
import numpy as np


L_WHEELBASE_DEFAULT = 2.5


class CBFTerms(NamedTuple):
    """Terms of the relative-degree-2 expansion
        hddot + (a1+a2) hdot + a1 a2 h  =  C + Ca * a + Cd * delta
    so the QP constraint is  C + Ca u[0] + Cd u[1] >= -inflation."""
    h:        float
    hdot:     float
    C_const:  float
    C_a:      float
    C_delta:  float


@dataclass
class FilterDiagnostics:
    """One line per filter call - what we log for the benchmark."""
    feasible: bool = True
    intervention: float = 0.0          # ||u* - u_nom||
    h_min: float = float("inf")        # most-violated barrier value
    solve_time_ms: float = 0.0
    notes: str = ""


@dataclass
class Obstacle:
    """Other vehicle / static obstacle on the road, in ego frame or world frame."""
    x: float
    y: float
    vx: float = 0.0
    vy: float = 0.0
    radius: float = 2.5     # bounding circle radius (~ vehicle half-length)


class SafetyFilter(ABC):
    """Abstract base class - concrete filters override `filter`."""

    name: str = "BASE"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0):
        # alpha is the class-K gain in   hdot >= -alpha h   (Ames et al. 2017)
        self.alpha = alpha
        self.safe_dist = safe_dist
        self.last_diag = FilterDiagnostics()

    # ---------------- shared helpers ----------------

    @staticmethod
    def h_distance(state: np.ndarray, obs: Obstacle, safe_dist: float) -> float:
        """h(x) = ||p_ego - p_obs||^2 - (r_safe + r_obs)^2.

        h(x) >= 0  <=>  safe.  Squared form gives a smooth gradient.
        Form used in Ames et al. (2017), Sec. III.B."""
        dx = state[0] - obs.x
        dy = state[1] - obs.y
        r  = safe_dist + obs.radius
        return dx * dx + dy * dy - r * r

    @staticmethod
    def grad_h_distance(state: np.ndarray, obs: Obstacle) -> np.ndarray:
        """dh/dx for the squared-distance barrier; partials in (x,y,v,psi)."""
        return np.array([
            2.0 * (state[0] - obs.x),
            2.0 * (state[1] - obs.y),
            0.0,
            0.0,
        ])

    @staticmethod
    def cbf_terms(state: np.ndarray, obs: Obstacle, safe_dist: float,
                  a1: float, a2: float,
                  L_wheel: float = L_WHEELBASE_DEFAULT) -> "CBFTerms":
        """Compute the relative-degree-2 expansion terms used by every
        filter in this benchmark, so the constraint is genuinely affine in
        u = [a, delta]:
                C_const + C_a * a + C_delta * delta  >=  -inflation
        with    C_const = hddot|_{u=0} + (a1+a2) hdot + a1 a2 h
        See Ames et al. 2017 / Xiao, Cassandras, Belta 2023 for the form."""
        x, y, v, psi = state
        dx, dy = x - obs.x, y - obs.y
        cpsi, spsi = np.cos(psi), np.sin(psi)
        rel_vx = v * cpsi - obs.vx
        rel_vy = v * spsi - obs.vy
        h     = dx * dx + dy * dy - (safe_dist + obs.radius) ** 2
        hdot  = 2 * dx * rel_vx + 2 * dy * rel_vy
        # Linearise psidot ~ (v/L) delta around delta=0
        psidot_coef = v / L_wheel
        C_const = (2 * (rel_vx ** 2 + rel_vy ** 2)
                   + (a1 + a2) * hdot
                   + a1 * a2 * h)
        C_a     = 2 * dx * cpsi + 2 * dy * spsi
        C_delta = (-2 * dx * v * spsi + 2 * dy * v * cpsi) * psidot_coef
        return CBFTerms(h=h, hdot=hdot,
                        C_const=C_const, C_a=C_a, C_delta=C_delta)

    # ---------------- the contract ------------------

    @abstractmethod
    def filter(self,
               state: np.ndarray,
               u_nom: np.ndarray,
               obstacles: List[Obstacle],
               dt: float) -> Tuple[np.ndarray, FilterDiagnostics]:
        """Take nominal input, return safe input + diagnostics."""
        ...
