"""
F4 -- HOCBF  (High-Order CBF), Xiao, Cassandras, Belta, Springer 2023.
F5 -- MR-CBF (Measurement-Robust CBF), Cosner et al., arXiv:2104.14030 (2021).

HOCBF mathematical statement (relative degree m):
    psi_0(x) := h(x)
    psi_k(x) := psi_{k-1}'(x, u) + alpha_k(psi_{k-1}(x))   k = 1,...,m
The safety constraint imposed in the QP is
    psi_m(x, u) >= 0
For our distance barrier with the bicycle model, h has relative degree 2
through  delta  and 1 through  a; we treat it as relative degree 2 in
order to actually engage the steering input.

MR-CBF mathematical statement:
Given measurement error  ||x_hat - x||  <=  e_x,
    Lfh(x_hat) + Lgh(x_hat) u + alpha h(x_hat)  -  L_h e_x  >=  0
where L_h is a Lipschitz bound on h and its first derivative (Cosner
et al. 2021, Thm 2).
"""
from __future__ import annotations
import time
import numpy as np
import cvxpy as cp

from .base import SafetyFilter, FilterDiagnostics, Obstacle
from ..utils.dynamics import A_MIN, A_MAX, DELTA_MAX, L_WHEELBASE


class HOCBF(SafetyFilter):
    """F4 - High-Order CBF (relative degree 2)."""
    name = "F4_HOCBF"

    def __init__(self, alpha1: float = 1.5, alpha2: float = 1.5,
                 safe_dist: float = 6.0):
        super().__init__(alpha=alpha1, safe_dist=safe_dist)
        self.alpha1 = alpha1
        self.alpha2 = alpha2

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        x, y, v, psi = state
        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >= A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]
        h_min = np.inf
        for obs in obstacles:
            dx, dy = x - obs.x, y - obs.y
            h = dx*dx + dy*dy - (self.safe_dist + obs.radius)**2
            h_min = min(h_min, h)

            # psi_1 = hdot + alpha1 * h
            cpsi = np.cos(psi); spsi = np.sin(psi)
            rel_vx = v * cpsi - obs.vx
            rel_vy = v * spsi - obs.vy
            hdot   = 2 * dx * rel_vx + 2 * dy * rel_vy
            psi1   = hdot + self.alpha1 * h

            # psi_2 = psi1_dot + alpha2 * psi1
            # psi1_dot wrt (a, delta):
            # d/dt[2 dx rel_vx] = 2 rel_vx^2 + 2 dx (a cos psi - v sin psi * psidot)
            # psidot = (v/L) tan(delta) -- linearise around delta=0 to keep QP affine
            # We linearise tan(delta) ~ delta so psidot ~ (v/L) delta.
            psidot_coef = v / L_WHEELBASE   # multiplies delta
            # psi1dot terms that DEPEND on u:
            #   2 dx * a * cos(psi) + 2 dy * a * sin(psi)               (acceleration)
            #  -2 dx * v * sin(psi) * psidot_coef * delta
            #  +2 dy * v * cos(psi) * psidot_coef * delta               (steering)
            psi1_dot_const = (2 * rel_vx**2 + 2 * rel_vy**2
                              + self.alpha1 * hdot)
            psi1_dot_a     = 2 * dx * cpsi + 2 * dy * spsi
            psi1_dot_delta = (-2 * dx * v * spsi + 2 * dy * v * cpsi) * psidot_coef

            constraints.append(
                psi1_dot_const + psi1_dot_a * u[0] + psi1_dot_delta * u[1]
                + self.alpha2 * psi1 >= 0
            )

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False
        u_star = np.array(u.value) if feas else np.array([A_MIN, 0.0])
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag


class MR_CBF(SafetyFilter):
    """F5 - Measurement-Robust CBF (Cosner et al. 2021)."""
    name = "F5_MR_CBF"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0,
                 e_x: float = 0.5, L_h: float = 4.0):
        """e_x is bound on ||x_hat - x||, L_h is the Lipschitz constant
        of h on the operating set (Cosner et al. 2021, Thm 2)."""
        super().__init__(alpha=alpha, safe_dist=safe_dist)
        self.e_x = e_x
        self.L_h = L_h

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >= A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]
        h_min = np.inf
        a1 = a2 = self.alpha
        for obs in obstacles:
            t = self.cbf_terms(state, obs, self.safe_dist, a1, a2)
            h_min = min(h_min, t.h)
            inflation = self.L_h * self.e_x   # Cosner et al. 2021, Thm 2
            constraints.append(t.C_const + t.C_a * u[0] + t.C_delta * u[1]
                               - inflation >= 0)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False
        u_star = np.array(u.value) if feas else np.array([A_MIN, 0.0])
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag
