"""
F6 -- Sampled-Data CBF (SD-CBF)        Breeden, Garg, Panagou, IEEE L-CSS 2021;
                                       Taylor, Dorobantu, Cosner, Yue, Ames,
                                       arXiv:2203.11470 (2022).
F7 -- Robust SD-CBF                    Oruganti, Naghizadeh, arXiv:2309.07022 (2023).
F8 -- Predictor-Feedback CBF (PF-CBF)  Jankovic, ACC 2018;
                                       Molnar, Kiss, Ames, Orosz,
                                       arXiv:2603.24566 (2026);
                                       Kim, Das, Kim, Ames, Burdick, Sloth,
                                       ECC 2025;
                                       Molnar, Orosz, Ames, IEEE T-IV 2023.

SD-CBF mathematical statement (Breeden, Garg, Panagou 2021, Thm 1):
For zero-order-hold control with sample period T,
    Lfh + Lgh u + alpha h - (T/2) * M  >=  0
where  M  is an upper bound on  ||(d/dt)(Lfh + Lgh u + alpha h)||
on the next inter-sample interval.

Robust SD-CBF (Oruganti, Naghizadeh 2023): inflate by an extra
disturbance bound  d_max:
    Lfh + Lgh u + alpha h - (T/2) M - L_d * d_max  >=  0.

Predictor-Feedback CBF (Jankovic 2018, Molnar et al. 2026, Kim et al. 2025):
For input-delayed system  xdot = f(x) + g(x) u(t - tau),
predict the state  tau  seconds ahead under the *currently held*
input, then enforce the CBF on the predicted state:
        x_pred(t) = phi(t; x(t), u_held)
        Lf h(x_pred) + Lg h(x_pred) u + alpha h(x_pred)  >= 0 .
This is the rigorous delay-aware line; Kim et al. (2025) add
adaptive online estimation of tau, which we plug into LAWS.
"""
from __future__ import annotations
import time
import numpy as np
import cvxpy as cp

from .base import SafetyFilter, FilterDiagnostics, Obstacle
from ..utils.dynamics import (A_MIN, A_MAX, DELTA_MAX, V_MAX,
                              step_rk4, f_continuous)


class SDCBF(SafetyFilter):
    """F6 - Sampled-Data CBF (Breeden, Garg, Panagou 2021)."""
    name = "F6_SDCBF"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0,
                 sample_T: float = 0.1, M_bound: float = 80.0):
        super().__init__(alpha=alpha, safe_dist=safe_dist)
        self.sample_T = sample_T   # zero-order-hold period
        self.M_bound  = M_bound    # bound on derivative of constraint

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        x, y, v, psi = state
        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >= A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]
        h_min = np.inf
        # Breeden et al. inflation term (T/2) * M
        inflation = 0.5 * self.sample_T * self.M_bound
        a1 = a2 = self.alpha
        for obs in obstacles:
            t = self.cbf_terms(state, obs, self.safe_dist, a1, a2)
            h_min = min(h_min, t.h)
            constraints.append(t.C_const + t.C_a * u[0] + t.C_delta * u[1]
                               - inflation >= 0)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False
        u_star = np.array(u.value) if feas else np.array([A_MIN, 0.0])
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag


class RobustSDCBF(SafetyFilter):
    """F7 - Robust Sampled-Data CBF (Oruganti, Naghizadeh 2023)."""
    name = "F7_RobustSDCBF"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0,
                 sample_T: float = 0.1, M_bound: float = 80.0,
                 d_max: float = 1.0, L_d: float = 1.0):
        super().__init__(alpha=alpha, safe_dist=safe_dist)
        self.sample_T = sample_T
        self.M_bound  = M_bound
        self.d_max    = d_max     # bound on disturbance
        self.L_d      = L_d       # Lipschitz wrt disturbance

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        x, y, v, psi = state
        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >= A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]
        h_min = np.inf
        inflation = (0.5 * self.sample_T * self.M_bound
                     + self.L_d * self.d_max)
        a1 = a2 = self.alpha
        for obs in obstacles:
            t = self.cbf_terms(state, obs, self.safe_dist, a1, a2)
            h_min = min(h_min, t.h)
            constraints.append(t.C_const + t.C_a * u[0] + t.C_delta * u[1]
                               - inflation >= 0)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False
        u_star = np.array(u.value) if feas else np.array([A_MIN, 0.0])
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=prob.status if feas else "infeasible",
        )
        return u_star, diag


class PredictorFeedbackCBF(SafetyFilter):
    """F8 - Predictor-Feedback CBF (Jankovic 2018; Molnar et al. 2026;
                                    Kim et al. 2025; Molnar, Orosz, Ames 2023).

    Given supervisor latency tau, integrate the closed-loop dynamics
    forward by  tau  using the most recently *applied* input  u_held,
    then enforce the CBF constraint on the predicted state."""
    name = "F8_PF_CBF"

    def __init__(self, alpha: float = 1.0, safe_dist: float = 6.0,
                 tau: float = 0.5, n_pred_steps: int = 5):
        super().__init__(alpha=alpha, safe_dist=safe_dist)
        self.tau          = tau
        self.n_pred_steps = max(1, int(n_pred_steps))
        self.u_held       = np.zeros(2)   # last applied input

    def _predict(self, state: np.ndarray, obstacles, tau: float):
        """Predict ego and obstacle states  tau  seconds ahead under
        zero-order-hold of  self.u_held  for the ego, and constant velocity
        for obstacles (textbook predictor; see Molnar et al. 2023)."""
        x_p = state.copy()
        h_step = tau / self.n_pred_steps
        for _ in range(self.n_pred_steps):
            x_p = step_rk4(x_p, self.u_held, h_step)
        # propagate obstacles with constant velocity
        obs_pred = []
        for o in obstacles:
            obs_pred.append(type(o)(
                x=o.x + o.vx * tau, y=o.y + o.vy * tau,
                vx=o.vx, vy=o.vy, radius=o.radius
            ))
        return x_p, obs_pred

    def filter(self, state, u_nom, obstacles, dt):
        t0 = time.time()
        x_pred, obs_pred = self._predict(state, obstacles, self.tau)

        u  = cp.Variable(2)
        cost = cp.sum_squares(u - np.asarray(u_nom))
        constraints = [
            u[0] >= A_MIN, u[0] <= A_MAX,
            u[1] >= -DELTA_MAX, u[1] <= DELTA_MAX,
        ]
        h_min = np.inf
        a1 = a2 = self.alpha
        for obs in obs_pred:
            t = self.cbf_terms(x_pred, obs, self.safe_dist, a1, a2)
            h_min = min(h_min, t.h)
            constraints.append(t.C_const + t.C_a * u[0] + t.C_delta * u[1] >= 0)

        prob = cp.Problem(cp.Minimize(cost), constraints)
        try:
            prob.solve(solver=cp.OSQP, warm_start=True, verbose=False)
            feas = prob.status in ("optimal", "optimal_inaccurate") and u.value is not None
        except Exception:
            feas = False
        u_star = np.array(u.value) if feas else np.array([A_MIN, 0.0])
        # store as the most-recently-applied input for next prediction
        self.u_held = u_star.copy()
        diag = FilterDiagnostics(
            feasible=feas,
            intervention=float(np.linalg.norm(u_star - np.asarray(u_nom))),
            h_min=float(h_min),
            solve_time_ms=(time.time() - t0) * 1000.0,
            notes=f"{prob.status} (tau={self.tau:.2f}s)" if feas else "infeasible",
        )
        return u_star, diag
