"""SafeBench-LLM filter zoo.  Nine published safety filters + LAWS wrapper."""
from .base                 import SafetyFilter, FilterDiagnostics, Obstacle
from .f01_cbf_qp           import NoSafetyFilter, CBF_QP
from .f23_isscbf_dcbf      import ISSf_CBF, DCBF
from .f45_hocbf_mrcbf      import HOCBF, MR_CBF
from .f678_sdcbf_pfcbf     import SDCBF, RobustSDCBF, PredictorFeedbackCBF
from .f9_mpc_laws          import MPC_CBF, LAWS

__all__ = [
    "SafetyFilter", "FilterDiagnostics", "Obstacle",
    "NoSafetyFilter", "CBF_QP", "ISSf_CBF", "DCBF",
    "HOCBF", "MR_CBF", "SDCBF", "RobustSDCBF", "PredictorFeedbackCBF",
    "MPC_CBF", "LAWS",
]


FILTER_REGISTRY = {
    "F0_NoSafety":    NoSafetyFilter,
    "F1_CBF_QP":      CBF_QP,
    "F2_ISSf_CBF":    ISSf_CBF,
    "F3_DCBF":        DCBF,
    "F4_HOCBF":       HOCBF,
    "F5_MR_CBF":      MR_CBF,
    "F6_SDCBF":       SDCBF,
    "F7_RobustSDCBF": RobustSDCBF,
    "F8_PF_CBF":      PredictorFeedbackCBF,
    "F9_MPC_CBF":     MPC_CBF,
}
