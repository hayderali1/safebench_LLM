"""
Kinematic bicycle model for the ego vehicle, consistent with Highway-Env.

State:  x = [x_pos, y_pos, v, psi]
Input:  u = [a, delta]   (acceleration, steering angle)

xdot   = v cos(psi)
ydot   = v sin(psi)
vdot   = a
psidot = (v / L) * tan(delta)

This is the same model used in Molnar, Orosz & Ames (2023) for delay-aware
driving / racing CBFs (arXiv:2109.07101) and in the LanguageMPC line.
"""
from __future__ import annotations
import numpy as np


L_WHEELBASE = 2.5          # m, typical Highway-Env vehicle
A_MAX       =  5.0         # m/s^2
A_MIN       = -7.0         # m/s^2 (hard braking)
DELTA_MAX   =  np.pi / 6   # ~30 deg
V_MAX       = 40.0         # m/s
V_MIN       =  0.0


def f_continuous(state: np.ndarray, u: np.ndarray, L: float = L_WHEELBASE) -> np.ndarray:
    """Continuous-time bicycle dynamics xdot = f(x,u)."""
    x, y, v, psi = state
    a, delta     = u
    return np.array([
        v * np.cos(psi),
        v * np.sin(psi),
        a,
        (v / L) * np.tan(delta),
    ])


def step_rk4(state: np.ndarray, u: np.ndarray, dt: float, L: float = L_WHEELBASE) -> np.ndarray:
    """Fourth-order Runge-Kutta integration."""
    k1 = f_continuous(state,                u, L)
    k2 = f_continuous(state + 0.5 * dt * k1, u, L)
    k3 = f_continuous(state + 0.5 * dt * k2, u, L)
    k4 = f_continuous(state +       dt * k3, u, L)
    return state + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)


def clip_input(u: np.ndarray) -> np.ndarray:
    return np.array([
        np.clip(u[0], A_MIN, A_MAX),
        np.clip(u[1], -DELTA_MAX, DELTA_MAX),
    ])
